"use client";

import React, { useState, useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface LogisticMapVisualizationProps {
  r: number;
  x0: number;
  iterations: number;
  visualizationType: string;
  width: number;
  height: number;
}

const LogisticMapVisualization: React.FC<LogisticMapVisualizationProps> = ({
  r,
  x0,
  iterations,
  visualizationType,
  width,
  height
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  
  useEffect(() => {
    if (!svgRef.current) return;
    
    // Clear previous visualization
    d3.select(svgRef.current).selectAll('*').remove();
    
    const svg = d3.select(svgRef.current);
    
    // Set margins
    const margin = { top: 20, right: 20, bottom: 40, left: 50 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    
    // Create a group element for the visualization
    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);
    
    // Add background
    g.append('rect')
      .attr('width', innerWidth)
      .attr('height', innerHeight)
      .attr('fill', 'rgba(0, 0, 0, 0.2)')
      .attr('rx', 5);
    
    // Create scales
    const xScale = d3.scaleLinear()
      .domain([0, 1])
      .range([0, innerWidth]);
    
    const yScale = d3.scaleLinear()
      .domain([0, 1])
      .range([innerHeight, 0]);
    
    // Add grid lines
    const gridLinesX = d3.range(0, 1.1, 0.2);
    const gridLinesY = d3.range(0, 1.1, 0.2);
    
    // Add vertical grid lines
    g.selectAll('.grid-line-x')
      .data(gridLinesX)
      .enter()
      .append('line')
      .attr('class', 'grid-line-x')
      .attr('x1', d => xScale(d))
      .attr('y1', 0)
      .attr('x2', d => xScale(d))
      .attr('y2', innerHeight)
      .attr('stroke', 'var(--viz-grid)')
      .attr('stroke-dasharray', '3,3');
    
    // Add horizontal grid lines
    g.selectAll('.grid-line-y')
      .data(gridLinesY)
      .enter()
      .append('line')
      .attr('class', 'grid-line-y')
      .attr('x1', 0)
      .attr('y1', d => yScale(d))
      .attr('x2', innerWidth)
      .attr('y2', d => yScale(d))
      .attr('stroke', 'var(--viz-grid)')
      .attr('stroke-dasharray', '3,3');
    
    // Render based on visualization type
    if (visualizationType === 'cobweb') {
      renderCobweb(g, innerWidth, innerHeight, xScale, yScale);
    } else if (visualizationType === 'time') {
      renderTimeSeries(g, innerWidth, innerHeight, xScale, yScale);
    } else if (visualizationType === 'bifurcation') {
      renderBifurcation(g, innerWidth, innerHeight, xScale, yScale);
    }
    
    // Add axes
    const xAxis = g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(d3.axisBottom(xScale))
      .attr('color', 'var(--text-secondary)');
    
    const yAxis = g.append('g')
      .call(d3.axisLeft(yScale))
      .attr('color', 'var(--text-secondary)');
    
    // Add axis labels
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', innerHeight + 35)
      .attr('text-anchor', 'middle')
      .attr('fill', 'var(--text-secondary)')
      .text('x');
    
    g.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('x', -innerHeight / 2)
      .attr('y', -40)
      .attr('text-anchor', 'middle')
      .attr('fill', 'var(--text-secondary)')
      .text('f(x)');
    
    // Add title
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', -5)
      .attr('text-anchor', 'middle')
      .attr('fill', 'var(--text-accent)')
      .text(`Logistic Map (r = ${r.toFixed(2)})`);
    
    function renderCobweb(
      g: d3.Selection<SVGGElement, unknown, null, undefined>, 
      width: number, 
      height: number,
      xScale: d3.ScaleLinear<number, number>,
      yScale: d3.ScaleLinear<number, number>
    ) {
      // Logistic function
      const logistic = (x: number) => r * x * (1 - x);
      
      // Draw the logistic curve
      const curve = d3.line<number>()
        .x(d => xScale(d))
        .y(d => yScale(logistic(d)));
      
      const points = d3.range(0, 1.001, 0.01);
      
      g.append('path')
        .datum(points)
        .attr('fill', 'none')
        .attr('stroke', 'var(--viz-primary)')
        .attr('stroke-width', 2)
        .attr('d', curve);
      
      // Draw the diagonal line (y = x)
      g.append('line')
        .attr('x1', xScale(0))
        .attr('y1', yScale(0))
        .attr('x2', xScale(1))
        .attr('y2', yScale(1))
        .attr('stroke', 'var(--viz-secondary)')
        .attr('stroke-width', 1)
        .attr('stroke-dasharray', '5,5');
      
      // Calculate and draw the cobweb
      const cobwebPoints = [];
      let x = x0;
      
      for (let i = 0; i < iterations; i++) {
        const y = logistic(x);
        cobwebPoints.push({ x, y });
        x = y;
      }
      
      // Draw vertical lines
      for (let i = 0; i < cobwebPoints.length - 1; i++) {
        g.append('line')
          .attr('x1', xScale(cobwebPoints[i].x))
          .attr('y1', yScale(cobwebPoints[i].y))
          .attr('x2', xScale(cobwebPoints[i].y))
          .attr('y2', yScale(cobwebPoints[i].y))
          .attr('stroke', 'var(--viz-tertiary)')
          .attr('stroke-width', 1.5);
      }
      
      // Draw horizontal lines
      for (let i = 0; i < cobwebPoints.length - 1; i++) {
        g.append('line')
          .attr('x1', xScale(cobwebPoints[i].y))
          .attr('y1', yScale(cobwebPoints[i].y))
          .attr('x2', xScale(cobwebPoints[i].y))
          .attr('y2', yScale(cobwebPoints[i + 1].y))
          .attr('stroke', 'var(--viz-tertiary)')
          .attr('stroke-width', 1.5);
      }
      
      // Add points
      g.selectAll('.cobweb-point')
        .data(cobwebPoints)
        .enter()
        .append('circle')
        .attr('class', 'cobweb-point')
        .attr('cx', d => xScale(d.x))
        .attr('cy', d => yScale(d.y))
        .attr('r', 3)
        .attr('fill', 'var(--viz-point)');
      
      // Add initial point
      g.append('circle')
        .attr('cx', xScale(x0))
        .attr('cy', yScale(0))
        .attr('r', 5)
        .attr('fill', 'var(--viz-accent)');
    }
    
    function renderTimeSeries(
      g: d3.Selection<SVGGElement, unknown, null, undefined>, 
      width: number, 
      height: number,
      xScale: d3.ScaleLinear<number, number>,
      yScale: d3.ScaleLinear<number, number>
    ) {
      // Logistic function
      const logistic = (x: number) => r * x * (1 - x);
      
      // Calculate time series
      const timeSeriesPoints = [];
      let x = x0;
      
      for (let i = 0; i < iterations; i++) {
        timeSeriesPoints.push(x);
        x = logistic(x);
      }
      
      // Create new scales for time series
      const timeScale = d3.scaleLinear()
        .domain([0, timeSeriesPoints.length - 1])
        .range([0, width]);
      
      // Create line generator
      const line = d3.line<number>()
        .x((_, i) => timeScale(i))
        .y(d => yScale(d));
      
      // Add the line path
      g.append('path')
        .datum(timeSeriesPoints)
        .attr('fill', 'none')
        .attr('stroke', 'var(--viz-primary)')
        .attr('stroke-width', 2)
        .attr('d', line);
      
      // Add points
      g.selectAll('.time-point')
        .data(timeSeriesPoints)
        .enter()
        .append('circle')
        .attr('class', 'time-point')
        .attr('cx', (_, i) => timeScale(i))
        .attr('cy', d => yScale(d))
        .attr('r', 3)
        .attr('fill', 'var(--viz-point)');
      
      // Update x-axis
      g.select('g.x-axis').remove();
      g.append('g')
        .attr('class', 'x-axis')
        .attr('transform', `translate(0,${innerHeight})`)
        .call(d3.axisBottom(timeScale))
        .attr('color', 'var(--text-secondary)');
      
      // Update x-axis label
      g.select('text.x-label').remove();
      g.append('text')
        .attr('class', 'x-label')
        .attr('x', innerWidth / 2)
        .attr('y', innerHeight + 35)
        .attr('text-anchor', 'middle')
        .attr('fill', 'var(--text-secondary)')
        .text('Iteration');
    }
    
    function renderBifurcation(
      g: d3.Selection<SVGGElement, unknown, null, undefined>, 
      width: number, 
      height: number,
      xScale: d3.ScaleLinear<number, number>,
      yScale: d3.ScaleLinear<number, number>
    ) {
      // Create new scales for bifurcation diagram
      const rScale = d3.scaleLinear()
        .domain([2.5, 4.0])
        .range([0, width]);
      
      // For each r value, calculate the attractor
      const rValues = d3.range(2.5, 4.001, 0.005);
      const bifurcationPoints = [];
      
      for (const rVal of rValues) {
        // Logistic function for this r value
        const logistic = (x: number) => rVal * x * (1 - x);
        
        // Calculate the attractor
        let x = 0.5; // Start with x0 = 0.5
        
        // Discard transient
        for (let i = 0; i < 100; i++) {
          x = logistic(x);
        }
        
        // Collect attractor points
        for (let i = 0; i < 50; i++) {
          x = logistic(x);
          bifurcationPoints.push({ r: rVal, x });
        }
      }
      
      // Add points
      g.selectAll('.bifurcation-point')
        .data(bifurcationPoints)
        .enter()
        .append('circle')
        .attr('class', 'bifurcation-point')
        .attr('cx', d => rScale(d.r))
        .attr('cy', d => yScale(d.x))
        .attr('r', 0.5)
        .attr('fill', 'var(--viz-point)')
        .attr('opacity', 0.7);
      
      // Add current r value line
      g.append('line')
        .attr('x1', rScale(r))
        .attr('y1', 0)
        .attr('x2', rScale(r))
        .attr('y2', height)
        .attr('stroke', 'var(--viz-tertiary)')
        .attr('stroke-width', 2)
        .attr('stroke-dasharray', '5,5');
      
      // Update x-axis
      g.select('g.x-axis').remove();
      g.append('g')
        .attr('class', 'x-axis')
        .attr('transform', `translate(0,${innerHeight})`)
        .call(d3.axisBottom(rScale))
        .attr('color', 'var(--text-secondary)');
      
      // Update x-axis label
      g.select('text.x-label').remove();
      g.append('text')
        .attr('class', 'x-label')
        .attr('x', innerWidth / 2)
        .attr('y', innerHeight + 35)
        .attr('text-anchor', 'middle')
        .attr('fill', 'var(--text-secondary)')
        .text('Parameter r');
    }
    
  }, [r, x0, iterations, visualizationType, width, height]);
  
  return (
    <svg ref={svgRef} width={width} height={height} className="overflow-visible visualization-container"></svg>
  );
};

export default LogisticMapVisualization;
