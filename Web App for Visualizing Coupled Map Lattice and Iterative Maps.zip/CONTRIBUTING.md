# Contributing to CML Visualizer

Thank you for considering contributing to CML Visualizer! This document provides guidelines and instructions for contributing to the project.

## Code of Conduct

Please be respectful and considerate of others when contributing to this project. We aim to foster an inclusive and welcoming community.

## How to Contribute

### Reporting Bugs

If you find a bug, please create an issue with the following information:
- A clear, descriptive title
- Steps to reproduce the bug
- Expected behavior
- Actual behavior
- Screenshots if applicable
- Environment information (browser, OS, device)

### Suggesting Features

Feature suggestions are welcome! Please create an issue with:
- A clear, descriptive title
- Detailed description of the proposed feature
- Any relevant mockups or examples
- Explanation of why this feature would be useful

### Pull Requests

1. Fork the repository
2. Create a new branch for your feature or bugfix
3. Make your changes
4. Ensure your code follows the project's style guidelines
5. Write tests if applicable
6. Update documentation as needed
7. Submit a pull request

## Development Setup

1. Clone the repository:
```bash
git clone https://github.com/yourusername/cml-visualizer.git
cd cml-visualizer
```

2. Install dependencies:
```bash
npm install
# or
pnpm install
```

3. Start the development server:
```bash
npm run dev
# or
pnpm dev
```

## Coding Standards

- Use TypeScript for type safety
- Follow the existing code style
- Use meaningful variable and function names
- Write comments for complex logic
- Keep components modular and reusable

## Testing

- Test your changes in multiple browsers
- Ensure compatibility with macOS devices
- Verify that all themes work correctly
- Check responsive design on different screen sizes

## Documentation

- Update README.md if you add new features
- Document any new components or functions
- Update installation or usage instructions if necessary

## License

By contributing to this project, you agree that your contributions will be licensed under the project's MIT license.
