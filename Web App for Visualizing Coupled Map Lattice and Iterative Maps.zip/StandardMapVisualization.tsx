import React, { useState, useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { calculateStandardMap, calculatePhaseSpace } from '@/lib/maps/standard';

interface StandardMapVisualizationProps {
  K: number;
  initialTheta: number;
  initialP: number;
  iterations: number;
  visualizationType: 'phasespace' | 'timeseries' | 'rotation' | 'stability';
  width: number;
  height: number;
}

const StandardMapVisualization: React.FC<StandardMapVisualizationProps> = ({
  K,
  initialTheta,
  initialP,
  iterations,
  visualizationType,
  width,
  height
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  
  useEffect(() => {
    if (!svgRef.current) return;
    
    // Clear previous visualization
    d3.select(svgRef.current).selectAll('*').remove();
    
    const svg = d3.select(svgRef.current);
    
    // Set margins
    const margin = { top: 20, right: 20, bottom: 40, left: 50 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    
    // Create a group element for the visualization
    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);
    
    // Add background
    g.append('rect')
      .attr('width', innerWidth)
      .attr('height', innerHeight)
      .attr('fill', 'rgba(0, 0, 0, 0.2)')
      .attr('rx', 5);
    
    // Create scales for the Standard map
    const xScale = d3.scaleLinear()
      .domain([0, 2 * Math.PI])
      .range([0, innerWidth]);
    
    const yScale = d3.scaleLinear()
      .domain([0, 2 * Math.PI])
      .range([innerHeight, 0]);
    
    // Add grid lines
    const gridLinesX = d3.range(0, 2 * Math.PI + 0.1, Math.PI / 2);
    const gridLinesY = d3.range(0, 2 * Math.PI + 0.1, Math.PI / 2);
    
    // Add vertical grid lines
    g.selectAll('.grid-line-x')
      .data(gridLinesX)
      .enter()
      .append('line')
      .attr('class', 'grid-line-x')
      .attr('x1', d => xScale(d))
      .attr('y1', 0)
      .attr('x2', d => xScale(d))
      .attr('y2', innerHeight)
      .attr('stroke', 'rgba(80, 250, 123, 0.1)')
      .attr('stroke-dasharray', '3,3');
    
    // Add horizontal grid lines
    g.selectAll('.grid-line-y')
      .data(gridLinesY)
      .enter()
      .append('line')
      .attr('class', 'grid-line-y')
      .attr('x1', 0)
      .attr('y1', d => yScale(d))
      .attr('x2', innerWidth)
      .attr('y2', d => yScale(d))
      .attr('stroke', 'rgba(80, 250, 123, 0.1)')
      .attr('stroke-dasharray', '3,3');
    
    // Render based on visualization type
    switch (visualizationType) {
      case 'phasespace':
        renderPhaseSpace(g, innerWidth, innerHeight, xScale, yScale);
        break;
      case 'timeseries':
        renderTimeSeries(g, innerWidth, innerHeight);
        break;
      case 'rotation':
        renderRotationNumber(g, innerWidth, innerHeight);
        break;
      case 'stability':
        renderStabilityTransition(g, innerWidth, innerHeight);
        break;
    }
    
    // Add axes
    const xAxis = g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(d3.axisBottom(xScale).tickValues([0, Math.PI/2, Math.PI, 3*Math.PI/2, 2*Math.PI])
        .tickFormat(d => {
          if (d === 0) return "0";
          if (d === Math.PI/2) return "π/2";
          if (d === Math.PI) return "π";
          if (d === 3*Math.PI/2) return "3π/2";
          if (d === 2*Math.PI) return "2π";
          return "";
        }))
      .attr('color', '#6272a4');
    
    const yAxis = g.append('g')
      .call(d3.axisLeft(yScale).tickValues([0, Math.PI/2, Math.PI, 3*Math.PI/2, 2*Math.PI])
        .tickFormat(d => {
          if (d === 0) return "0";
          if (d === Math.PI/2) return "π/2";
          if (d === Math.PI) return "π";
          if (d === 3*Math.PI/2) return "3π/2";
          if (d === 2*Math.PI) return "2π";
          return "";
        }))
      .attr('color', '#6272a4');
    
    // Add axis labels
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', innerHeight + 35)
      .attr('text-anchor', 'middle')
      .attr('fill', '#50fa7b')
      .text('θ');
    
    g.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('x', -innerHeight / 2)
      .attr('y', -40)
      .attr('text-anchor', 'middle')
      .attr('fill', '#50fa7b')
      .text('p');
    
    // Add title
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', -5)
      .attr('text-anchor', 'middle')
      .attr('fill', '#50fa7b')
      .text(`Standard Map (K = ${K.toFixed(2)})`);
    
    function renderPhaseSpace(
      g: d3.Selection<SVGGElement, unknown, null, undefined>, 
      width: number, 
      height: number,
      xScale: d3.ScaleLinear<number, number>,
      yScale: d3.ScaleLinear<number, number>
    ) {
      // Calculate multiple trajectories for phase space visualization
      const trajectories = calculatePhaseSpace(K, 20, 500);
      
      // Add the trajectories
      trajectories.forEach((trajectory, i) => {
        g.append('path')
          .datum(trajectory)
          .attr('fill', 'none')
          .attr('stroke', d3.interpolateViridis(i / trajectories.length))
          .attr('stroke-width', 1)
          .attr('opacity', 0.7)
          .attr('d', d3.line<[number, number]>()
            .x(d => xScale(d[0]))
            .y(d => yScale(d[1]))
          );
      });
      
      // Calculate and add the main trajectory
      const mainTrajectory = calculateStandardMap(K, initialTheta, initialP, iterations);
      
      g.append('path')
        .datum(mainTrajectory)
        .attr('fill', 'none')
        .attr('stroke', '#ff79c6')
        .attr('stroke-width', 2)
        .attr('d', d3.line<[number, number]>()
          .x(d => xScale(d[0]))
          .y(d => yScale(d[1]))
        );
      
      // Add initial point
      g.append('circle')
        .attr('cx', xScale(initialTheta))
        .attr('cy', yScale(initialP))
        .attr('r', 4)
        .attr('fill', '#f1fa8c');
    }
    
    function renderTimeSeries(g: d3.Selection<SVGGElement, unknown, null, undefined>, width: number, height: number) {
      // Calculate the Standard map iterations
      const data = calculateStandardMap(K, initialTheta, initialP, iterations);
      
      // Create scales
      const xScale = d3.scaleLinear()
        .domain([0, data.length - 1])
        .range([0, width]);
      
      const yScaleTheta = d3.scaleLinear()
        .domain([0, 2 * Math.PI])
        .range([height / 2 - 10, 0]);
      
      const yScaleP = d3.scaleLinear()
        .domain([0, 2 * Math.PI])
        .range([height, height / 2 + 10]);
      
      // Create line generators
      const lineTheta = d3.line<[number, number]>()
        .x((_, i) => xScale(i))
        .y(d => yScaleTheta(d[0]));
      
      const lineP = d3.line<[number, number]>()
        .x((_, i) => xScale(i))
        .y(d => yScaleP(d[1]));
      
      // Add separator line
      g.append('line')
        .attr('x1', 0)
        .attr('y1', height / 2)
        .attr('x2', width)
        .attr('y2', height / 2)
        .attr('stroke', '#6272a4')
        .attr('stroke-width', 1)
        .attr('stroke-dasharray', '5,5');
      
      // Add the theta time series
      g.append('path')
        .datum(data)
        .attr('fill', 'none')
        .attr('stroke', '#50fa7b')
        .attr('stroke-width', 2)
        .attr('d', lineTheta);
      
      // Add the p time series
      g.append('path')
        .datum(data)
        .attr('fill', 'none')
        .attr('stroke', '#8be9fd')
        .attr('stroke-width', 2)
        .attr('d', lineP);
      
      // Add labels
      g.append('text')
        .attr('x', 10)
        .attr('y', 20)
        .attr('fill', '#50fa7b')
        .text('θ(t)');
      
      g.append('text')
        .attr('x', 10)
        .attr('y', height / 2 + 20)
        .attr('fill', '#8be9fd')
        .text('p(t)');
    }
    
    function renderRotationNumber(g: d3.Selection<SVGGElement, unknown, null, undefined>, width: number, height: number) {
      // Placeholder for rotation number visualization
      g.append('text')
        .attr('x', innerWidth / 2)
        .attr('y', innerHeight / 2)
        .attr('text-anchor', 'middle')
        .attr('fill', '#50fa7b')
        .text('Rotation Number Visualization Coming Soon');
    }
    
    function renderStabilityTransition(g: d3.Selection<SVGGElement, unknown, null, undefined>, width: number, height: number) {
      // Placeholder for stability transition visualization
      g.append('text')
        .attr('x', innerWidth / 2)
        .attr('y', innerHeight / 2)
        .attr('text-anchor', 'middle')
        .attr('fill', '#50fa7b')
        .text('Stability Transition Visualization Coming Soon');
      
      // Add current K value marker
      g.append('line')
        .attr('x1', innerWidth * K / 5)
        .attr('y1', 0)
        .attr('x2', innerWidth * K / 5)
        .attr('y2', innerHeight)
        .attr('stroke', '#ff5555')
        .attr('stroke-width', 2)
        .attr('stroke-dasharray', '5,5');
    }
    
  }, [K, initialTheta, initialP, iterations, visualizationType, width, height]);
  
  return (
    <svg ref={svgRef} width={width} height={height} className="overflow-visible"></svg>
  );
};

export default StandardMapVisualization;
