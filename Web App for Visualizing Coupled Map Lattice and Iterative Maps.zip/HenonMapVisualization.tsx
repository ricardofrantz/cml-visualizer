"use client";

import React, { useState, useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { calculateHenonMap, calculateHenonAttractor } from '@/lib/maps/henon';

interface HenonMapVisualizationProps {
  a: number;
  b: number;
  x0: number;
  y0: number;
  iterations: number;
  visualizationType: string;
  width: number;
  height: number;
}

const HenonMapVisualization: React.FC<HenonMapVisualizationProps> = ({
  a,
  b,
  x0,
  y0,
  iterations,
  visualizationType,
  width,
  height
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  
  useEffect(() => {
    if (!svgRef.current) return;
    
    // Clear previous visualization
    d3.select(svgRef.current).selectAll('*').remove();
    
    const svg = d3.select(svgRef.current);
    
    // Set margins
    const margin = { top: 20, right: 20, bottom: 40, left: 50 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    
    // Create a group element for the visualization
    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);
    
    // Add background
    g.append('rect')
      .attr('width', innerWidth)
      .attr('height', innerHeight)
      .attr('fill', 'rgba(0, 0, 0, 0.2)')
      .attr('rx', 5);
    
    // Add grid lines
    const gridLinesX = d3.range(-2, 2.1, 0.5);
    const gridLinesY = d3.range(-2, 2.1, 0.5);
    
    // Create scales
    const xScale = d3.scaleLinear()
      .domain([-2, 2])
      .range([0, innerWidth]);
    
    const yScale = d3.scaleLinear()
      .domain([-2, 2])
      .range([innerHeight, 0]);
    
    // Add vertical grid lines
    g.selectAll('.grid-line-x')
      .data(gridLinesX)
      .enter()
      .append('line')
      .attr('class', 'grid-line-x')
      .attr('x1', d => xScale(d))
      .attr('y1', 0)
      .attr('x2', d => xScale(d))
      .attr('y2', innerHeight)
      .attr('stroke', 'var(--viz-grid)')
      .attr('stroke-dasharray', '3,3');
    
    // Add horizontal grid lines
    g.selectAll('.grid-line-y')
      .data(gridLinesY)
      .enter()
      .append('line')
      .attr('class', 'grid-line-y')
      .attr('x1', 0)
      .attr('y1', d => yScale(d))
      .attr('x2', innerWidth)
      .attr('y2', d => yScale(d))
      .attr('stroke', 'var(--viz-grid)')
      .attr('stroke-dasharray', '3,3');
    
    // Render based on visualization type
    if (visualizationType === 'phase') {
      renderPhaseSpace(g, innerWidth, innerHeight, xScale, yScale);
    } else if (visualizationType === 'time') {
      renderTimeSeries(g, innerWidth, innerHeight, xScale, yScale);
    } else if (visualizationType === 'bifurcation') {
      renderBifurcation(g, innerWidth, innerHeight, xScale, yScale);
    }
    
    // Add axes
    const xAxis = g.append('g')
      .attr('transform', `translate(0,${innerHeight / 2})`)
      .call(d3.axisBottom(xScale))
      .attr('color', 'var(--text-secondary)');
    
    const yAxis = g.append('g')
      .attr('transform', `translate(${innerWidth / 2},0)`)
      .call(d3.axisLeft(yScale))
      .attr('color', 'var(--text-secondary)');
    
    // Add axis labels
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', innerHeight + 35)
      .attr('text-anchor', 'middle')
      .attr('fill', 'var(--text-secondary)')
      .text('x');
    
    g.append('text')
      .attr('transform', 'rotate(-90)')
      .attr('x', -innerHeight / 2)
      .attr('y', -40)
      .attr('text-anchor', 'middle')
      .attr('fill', 'var(--text-secondary)')
      .text('y');
    
    // Add title
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', -5)
      .attr('text-anchor', 'middle')
      .attr('fill', 'var(--text-accent)')
      .text(`Hénon Map (a = ${a.toFixed(2)}, b = ${b.toFixed(2)})`);
    
    function renderPhaseSpace(
      g: d3.Selection<SVGGElement, unknown, null, undefined>, 
      width: number, 
      height: number,
      xScale: d3.ScaleLinear<number, number>,
      yScale: d3.ScaleLinear<number, number>
    ) {
      // Calculate the Hénon attractor
      const points = calculateHenonAttractor(a, b, x0, y0, iterations);
      
      // Add points
      g.selectAll('.point')
        .data(points)
        .enter()
        .append('circle')
        .attr('class', 'point')
        .attr('cx', d => xScale(d.x))
        .attr('cy', d => yScale(d.y))
        .attr('r', 1)
        .attr('fill', 'var(--viz-point)')
        .attr('opacity', 0.7);
      
      // Add initial point
      g.append('circle')
        .attr('cx', xScale(x0))
        .attr('cy', yScale(y0))
        .attr('r', 4)
        .attr('fill', 'var(--viz-tertiary)');
    }
    
    function renderTimeSeries(
      g: d3.Selection<SVGGElement, unknown, null, undefined>, 
      width: number, 
      height: number,
      xScale: d3.ScaleLinear<number, number>,
      yScale: d3.ScaleLinear<number, number>
    ) {
      // Calculate the Hénon map iterations
      const points = calculateHenonAttractor(a, b, x0, y0, iterations);
      
      // Create new scales for time series
      const timeScale = d3.scaleLinear()
        .domain([0, points.length - 1])
        .range([0, width]);
      
      // Create line generators
      const xLine = d3.line<{x: number, y: number}>()
        .x((_, i) => timeScale(i))
        .y(d => yScale(d.x));
      
      const yLine = d3.line<{x: number, y: number}>()
        .x((_, i) => timeScale(i))
        .y(d => yScale(d.y));
      
      // Add the x line path
      g.append('path')
        .datum(points)
        .attr('fill', 'none')
        .attr('stroke', 'var(--viz-primary)')
        .attr('stroke-width', 1.5)
        .attr('d', xLine);
      
      // Add the y line path
      g.append('path')
        .datum(points)
        .attr('fill', 'none')
        .attr('stroke', 'var(--viz-secondary)')
        .attr('stroke-width', 1.5)
        .attr('d', yLine);
      
      // Add legend
      g.append('line')
        .attr('x1', width - 100)
        .attr('y1', 20)
        .attr('x2', width - 80)
        .attr('y2', 20)
        .attr('stroke', 'var(--viz-primary)')
        .attr('stroke-width', 1.5);
      
      g.append('text')
        .attr('x', width - 75)
        .attr('y', 24)
        .attr('fill', 'var(--text-secondary)')
        .text('x(t)');
      
      g.append('line')
        .attr('x1', width - 100)
        .attr('y1', 40)
        .attr('x2', width - 80)
        .attr('y2', 40)
        .attr('stroke', 'var(--viz-secondary)')
        .attr('stroke-width', 1.5);
      
      g.append('text')
        .attr('x', width - 75)
        .attr('y', 44)
        .attr('fill', 'var(--text-secondary)')
        .text('y(t)');
    }
    
    function renderBifurcation(
      g: d3.Selection<SVGGElement, unknown, null, undefined>, 
      width: number, 
      height: number,
      xScale: d3.ScaleLinear<number, number>,
      yScale: d3.ScaleLinear<number, number>
    ) {
      // For bifurcation diagram, we'll use a placeholder for now
      g.append('text')
        .attr('x', width / 2)
        .attr('y', height / 2)
        .attr('text-anchor', 'middle')
        .attr('fill', 'var(--text-accent)')
        .text('Bifurcation Diagram Coming Soon');
      
      // Add current parameter value line
      g.append('line')
        .attr('x1', xScale(a))
        .attr('y1', 0)
        .attr('x2', xScale(a))
        .attr('y2', height)
        .attr('stroke', 'var(--viz-tertiary)')
        .attr('stroke-width', 2)
        .attr('stroke-dasharray', '5,5');
    }
    
  }, [a, b, x0, y0, iterations, visualizationType, width, height]);
  
  return (
    <svg ref={svgRef} width={width} height={height} className="overflow-visible visualization-container"></svg>
  );
};

export default HenonMapVisualization;
