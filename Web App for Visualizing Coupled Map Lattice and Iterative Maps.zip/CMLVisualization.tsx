"use client";

import React, { useState, useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { calculateDiffusiveCML, calculateGlobalCML, calculateDirectionalCML, calculateSpatialPowerSpectrum } from '@/lib/maps/cml';

interface CMLVisualizationProps {
  r: number;
  epsilon: number;
  latticeSize: number;
  timeSteps: number;
  visualizationType: 'spacetime' | 'spectrum' | 'evolution';
  couplingType: 'diffusive' | 'global' | 'directional';
  width: number;
  height: number;
}

const CMLVisualization: React.FC<CMLVisualizationProps> = ({
  r,
  epsilon,
  latticeSize,
  timeSteps,
  visualizationType,
  couplingType,
  width,
  height
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  
  useEffect(() => {
    if (!svgRef.current) return;
    
    // Clear previous visualization
    d3.select(svgRef.current).selectAll('*').remove();
    
    const svg = d3.select(svgRef.current);
    
    // Set margins
    const margin = { top: 20, right: 20, bottom: 40, left: 50 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;
    
    // Create a group element for the visualization
    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);
    
    // Calculate CML data based on coupling type
    let cmlData: number[][] = [];
    switch (couplingType) {
      case 'diffusive':
        cmlData = calculateDiffusiveCML(r, epsilon, latticeSize, timeSteps);
        break;
      case 'global':
        cmlData = calculateGlobalCML(r, epsilon, latticeSize, timeSteps);
        break;
      case 'directional':
        cmlData = calculateDirectionalCML(r, epsilon, latticeSize, timeSteps);
        break;
    }
    
    // Render based on visualization type
    switch (visualizationType) {
      case 'spacetime':
        renderSpaceTimePlot(g, cmlData, innerWidth, innerHeight);
        break;
      case 'spectrum':
        renderPowerSpectrum(g, cmlData, innerWidth, innerHeight);
        break;
      case 'evolution':
        renderTimeEvolution(g, cmlData, innerWidth, innerHeight);
        break;
    }
    
    // Add title
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', -5)
      .attr('text-anchor', 'middle')
      .attr('fill', 'var(--text-accent)')
      .text(`${couplingType.charAt(0).toUpperCase() + couplingType.slice(1)} CML (r = ${r.toFixed(2)}, ε = ${epsilon.toFixed(2)})`);
    
    function renderSpaceTimePlot(
      g: d3.Selection<SVGGElement, unknown, null, undefined>, 
      data: number[][], 
      width: number, 
      height: number
    ) {
      // Create a canvas for the space-time plot
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const context = canvas.getContext('2d')!;
      
      // Create an image data object
      const imageData = context.createImageData(width, height);
      
      // Map CML data to pixel values
      for (let t = 0; t < Math.min(data.length, height); t++) {
        for (let x = 0; x < Math.min(data[t].length, width); x++) {
          // Calculate the index in the image data array (4 values per pixel: r, g, b, a)
          const idx = (t * width + x) * 4;
          
          // Map the CML value to a color
          const value = data[t][x];
          
          // Use theme colors for visualization
          const r = Math.floor(255 * (1 - value)); // Red decreases with value
          const g = Math.floor(255 * Math.sin(Math.PI * value)); // Green peaks at middle values
          const b = Math.floor(255 * value); // Blue increases with value
          
          imageData.data[idx] = r;
          imageData.data[idx + 1] = g;
          imageData.data[idx + 2] = b;
          imageData.data[idx + 3] = 255; // Alpha (fully opaque)
        }
      }
      
      // Put the image data on the canvas
      context.putImageData(imageData, 0, 0);
      
      // Convert canvas to image and add to SVG
      const image = new Image();
      image.src = canvas.toDataURL();
      
      // Add the image to the SVG
      g.append('image')
        .attr('xlink:href', image.src)
        .attr('width', width)
        .attr('height', height);
      
      // Add axes
      const xScale = d3.scaleLinear()
        .domain([0, latticeSize])
        .range([0, width]);
      
      const yScale = d3.scaleLinear()
        .domain([0, timeSteps])
        .range([0, height]);
      
      const xAxis = d3.axisBottom(xScale);
      const yAxis = d3.axisLeft(yScale);
      
      g.append('g')
        .attr('transform', `translate(0,${height})`)
        .call(xAxis)
        .attr('color', 'var(--text-secondary)');
      
      g.append('g')
        .call(yAxis)
        .attr('color', 'var(--text-secondary)');
      
      // Add axis labels
      g.append('text')
        .attr('x', width / 2)
        .attr('y', height + 35)
        .attr('text-anchor', 'middle')
        .attr('fill', 'var(--text-secondary)')
        .text('Space');
      
      g.append('text')
        .attr('transform', 'rotate(-90)')
        .attr('x', -height / 2)
        .attr('y', -40)
        .attr('text-anchor', 'middle')
        .attr('fill', 'var(--text-secondary)')
        .text('Time');
    }
    
    function renderPowerSpectrum(
      g: d3.Selection<SVGGElement, unknown, null, undefined>, 
      data: number[][], 
      width: number, 
      height: number
    ) {
      // Calculate the power spectrum for the last time step
      const lastTimeStep = data[data.length - 1];
      const spectrum = calculateSpatialPowerSpectrum(lastTimeStep);
      
      // Create scales
      const xScale = d3.scaleLinear()
        .domain([0, spectrum.length])
        .range([0, width]);
      
      const yScale = d3.scaleLog()
        .domain([0.001, d3.max(spectrum) || 1])
        .range([height, 0]);
      
      // Create line generator
      const line = d3.line<number>()
        .x((_, i) => xScale(i))
        .y(d => yScale(Math.max(0.001, d)));
      
      // Add the line path
      g.append('path')
        .datum(spectrum)
        .attr('fill', 'none')
        .attr('stroke', 'var(--viz-primary)')
        .attr('stroke-width', 2)
        .attr('d', line);
      
      // Add axes
      const xAxis = d3.axisBottom(xScale);
      const yAxis = d3.axisLeft(yScale);
      
      g.append('g')
        .attr('transform', `translate(0,${height})`)
        .call(xAxis)
        .attr('color', 'var(--text-secondary)');
      
      g.append('g')
        .call(yAxis)
        .attr('color', 'var(--text-secondary)');
      
      // Add axis labels
      g.append('text')
        .attr('x', width / 2)
        .attr('y', height + 35)
        .attr('text-anchor', 'middle')
        .attr('fill', 'var(--text-secondary)')
        .text('Wavenumber');
      
      g.append('text')
        .attr('transform', 'rotate(-90)')
        .attr('x', -height / 2)
        .attr('y', -40)
        .attr('text-anchor', 'middle')
        .attr('fill', 'var(--text-secondary)')
        .text('Power');
    }
    
    function renderTimeEvolution(
      g: d3.Selection<SVGGElement, unknown, null, undefined>, 
      data: number[][], 
      width: number, 
      height: number
    ) {
      // Select a few sites to display their time evolution
      const selectedSites = [
        Math.floor(latticeSize * 0.25),
        Math.floor(latticeSize * 0.5),
        Math.floor(latticeSize * 0.75)
      ];
      
      // Create scales
      const xScale = d3.scaleLinear()
        .domain([0, data.length - 1])
        .range([0, width]);
      
      const yScale = d3.scaleLinear()
        .domain([0, 1])
        .range([height, 0]);
      
      // Create line generators for each selected site
      const colors = ['var(--viz-primary)', 'var(--viz-secondary)', 'var(--viz-tertiary)'];
      
      selectedSites.forEach((site, i) => {
        // Extract time series for this site
        const timeSeries = data.map(row => row[site]);
        
        // Create line generator
        const line = d3.line<number>()
          .x((_, t) => xScale(t))
          .y(d => yScale(d));
        
        // Add the line path
        g.append('path')
          .datum(timeSeries)
          .attr('fill', 'none')
          .attr('stroke', colors[i % colors.length])
          .attr('stroke-width', 2)
          .attr('d', line);
        
        // Add legend
        g.append('line')
          .attr('x1', width - 100)
          .attr('y1', 20 + i * 20)
          .attr('x2', width - 80)
          .attr('y2', 20 + i * 20)
          .attr('stroke', colors[i % colors.length])
          .attr('stroke-width', 2);
        
        g.append('text')
          .attr('x', width - 75)
          .attr('y', 24 + i * 20)
          .attr('fill', 'var(--text-secondary)')
          .text(`Site ${site}`);
      });
      
      // Add axes
      const xAxis = d3.axisBottom(xScale);
      const yAxis = d3.axisLeft(yScale);
      
      g.append('g')
        .attr('transform', `translate(0,${height})`)
        .call(xAxis)
        .attr('color', 'var(--text-secondary)');
      
      g.append('g')
        .call(yAxis)
        .attr('color', 'var(--text-secondary)');
      
      // Add axis labels
      g.append('text')
        .attr('x', width / 2)
        .attr('y', height + 35)
        .attr('text-anchor', 'middle')
        .attr('fill', 'var(--text-secondary)')
        .text('Time');
      
      g.append('text')
        .attr('transform', 'rotate(-90)')
        .attr('x', -height / 2)
        .attr('y', -40)
        .attr('text-anchor', 'middle')
        .attr('fill', 'var(--text-secondary)')
        .text('Value');
    }
    
  }, [r, epsilon, latticeSize, timeSteps, visualizationType, couplingType, width, height]);
  
  return (
    <svg ref={svgRef} width={width} height={height} className="overflow-visible visualization-container"></svg>
  );
};

export default CMLVisualization;
